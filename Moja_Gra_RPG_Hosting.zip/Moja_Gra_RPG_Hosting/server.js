'use strict';

const http = require('node:http');
const { Server } = require('socket.io');
const { randomUUID } = require('node:crypto');

const PORT = Number(process.env.PORT) || 3000;
const OPENAI_API_KEY = process.env.OPENAI_API_KEY || '';
const OPENAI_MODEL = process.env.OPENAI_MODEL || 'gpt-6.1-sol';
const WORLD_W = 2600;
const WORLD_H = 2100;
const MAX_ROOM_EDITS = 120;
const AI_COOLDOWN_MS = 5000;
const AI_IP_WINDOW_MS = 10 * 60 * 1000;
const AI_IP_MAX_REQUESTS = 12;

const httpServer = http.createServer((req, res) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  if (req.url === '/healthz' || req.url === '/health') {
    res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' });
    res.end(JSON.stringify({ ok: true, service: 'moja-gra-rpg', uptime: Math.round(process.uptime()) }));
    return;
  }
  res.writeHead(200, { 'Content-Type': 'text/plain; charset=utf-8' });
  res.end('Moja Gra RPG — serwer multiplayer działa.');
});

const io = new Server(httpServer, {
  cors: { origin: '*', methods: ['GET', 'POST'] },
  pingInterval: 25000,
  pingTimeout: 20000,
  maxHttpBufferSize: 1e6
});

// Active room state is held on the server. Room map edits are broadcast to
// every player and are also sent to anyone who joins an existing room.
const rooms = new Map();
const aiIpUsage = new Map();
const CODE_CHARS = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';

function makeCode() {
  let code;
  do {
    code = Array.from({ length: 12 }, () => CODE_CHARS[Math.floor(Math.random() * CODE_CHARS.length)]).join('');
  } while (rooms.has(code));
  return code;
}

function cleanName(value) {
  return String(value || 'Podróżnik').trim().replace(/[<>\u0000-\u001f]/g, '').slice(0, 16) || 'Podróżnik';
}

function cleanColor(value) {
  const color = String(value || '#4f91e8');
  return /^#[0-9a-fA-F]{6}$/.test(color) ? color : '#4f91e8';
}

function clamp(value, min, max) {
  return Math.max(min, Math.min(max, value));
}

function cleanCoordinate(value, max) {
  const number = Number(value);
  return Number.isFinite(number) ? clamp(Math.round(number), 40, max - 40) : null;
}

function publicPlayer(player) {
  return {
    id: player.id,
    nick: player.nick,
    color: player.color,
    x: player.x,
    y: player.y,
    direction: player.direction || 'down'
  };
}

function sanitizeOperations(value) {
  if (!Array.isArray(value)) return [];
  const operations = [];

  for (const raw of value.slice(0, 8)) {
    if (!raw || typeof raw !== 'object') continue;
    const type = String(raw.type || '');
    const x = cleanCoordinate(raw.x, WORLD_W);
    const y = cleanCoordinate(raw.y, WORLD_H);

    if (type === 'add_path') {
      const points = Array.isArray(raw.points) ? raw.points.slice(0, 8).map((point) => ({
        x: cleanCoordinate(point?.x, WORLD_W),
        y: cleanCoordinate(point?.y, WORLD_H)
      })) : [];
      if (points.length >= 2 && points.every((point) => point.x !== null && point.y !== null)) {
        operations.push({ type, points });
      }
      continue;
    }
    if (x === null || y === null) continue;

    if (type === 'add_house') {
      operations.push({ type, x, y, roof: raw.roof === 'teal' ? 'teal' : 'wood' });
    } else if (type === 'add_tree') {
      operations.push({ type, x, y, tone: Math.round(clamp(Number(raw.tone) || 0, 0, 3)), variant: Math.round(clamp(Number(raw.variant) || 0, 0, 2)) });
    } else if (type === 'add_decoration') {
      const kind = ['lamp', 'sign', 'crate', 'pot', 'flowers'].includes(raw.kind) ? raw.kind : null;
      if (kind) operations.push({ type, kind, x, y });
    } else if (type === 'add_flower_patch') {
      const allowedColors = ['#f1a6c8', '#f6d66f', '#f3eee0', '#bba4ed', '#e88c83'];
      const color = allowedColors.includes(String(raw.color).toLowerCase()) ? String(raw.color).toLowerCase() : '#f1a6c8';
      operations.push({ type, x, y, color });
    }
  }

  return operations;
}

function extractOutputText(response) {
  if (typeof response.output_text === 'string' && response.output_text.trim()) return response.output_text.trim();
  const chunks = [];
  for (const item of response.output || []) {
    if (item.type !== 'message') continue;
    for (const part of item.content || []) {
      if (part.type === 'output_text' && typeof part.text === 'string') chunks.push(part.text);
    }
  }
  return chunks.join('\n').trim();
}

async function askMapBuilder(prompt, position) {
  if (!OPENAI_API_KEY) {
    throw new Error('AI nie jest jeszcze podłączone. Na serwerze ustaw zmienną OPENAI_API_KEY i uruchom go ponownie.');
  }

  const systemInstructions = [
    'Jesteś AI Developerem w grze 2D RPG z widokiem z góry. Projektujesz małą, czytelną wioskę pixel-art.',
    'Odpowiadaj WYŁĄCZNIE poprawnym JSON-em bez markdown i bez tekstu poza JSON-em.',
    'Format: {"message":"krótki tekst po polsku","operations":[...]}. Maksymalnie 8 operacji.',
    `Świat ma współrzędne x od 0 do ${WORLD_W}, y od 0 do ${WORLD_H}. Współrzędne środka edycji gracza są podane w poleceniu.`,
    'Dozwolone operacje:',
    '1) {"type":"add_house","x":liczba,"y":liczba,"roof":"wood" albo "teal"}',
    '2) {"type":"add_tree","x":liczba,"y":liczba,"tone":0-3,"variant":0-2}',
    '3) {"type":"add_decoration","kind":"lamp" albo "sign" albo "crate" albo "pot" albo "flowers","x":liczba,"y":liczba}',
    '4) {"type":"add_flower_patch","x":liczba,"y":liczba,"color":"#f1a6c8" albo "#f6d66f" albo "#f3eee0" albo "#bba4ed" albo "#e88c83"}',
    '5) {"type":"add_path","points":[{"x":liczba,"y":liczba},{"x":liczba,"y":liczba}, ...]} — od 2 do 8 punktów.',
    'Nie wymyślaj innych typów operacji. Nie buduj na samym graczu, wodzie, domach ani poza mapą. Zostaw przejścia na ścieżkach i miejsce do chodzenia.',
    'Dla zwykłej prośby o rozmowę zwróć operations jako pustą tablicę i odpowiedz krótkim tekstem.'
  ].join('\n');

  const userInput = `Pozycja gracza: x=${position.x}, y=${position.y}.\nPolecenie gracza: ${prompt}\nZaplanuj zmianę mapy blisko tej pozycji, chyba że gracz wskaże inny obszar.`;
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 45000);
  try {
    const response = await fetch('https://api.openai.com/v1/responses', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${OPENAI_API_KEY}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        model: OPENAI_MODEL,
        instructions: systemInstructions,
        input: userInput,
        text: { format: { type: 'json_object' } },
        max_output_tokens: 1200,
        store: false
      }),
      signal: controller.signal
    });

    const body = await response.json().catch(() => ({}));
    if (!response.ok) {
      const message = body?.error?.message || `Błąd API (${response.status}).`;
      throw new Error(message.slice(0, 260));
    }

    const output = extractOutputText(body);
    if (!output) throw new Error('AI zwróciło pustą odpowiedź. Spróbuj ponownie.');
    let parsed;
    try {
      parsed = JSON.parse(output);
    } catch {
      throw new Error('AI zwróciło niepoprawny plan. Spróbuj opisać zmianę prościej.');
    }

    return {
      message: String(parsed.message || 'Gotowe — przygotowałem zmianę mapy.').replace(/[<>\u0000-\u001f]/g, '').slice(0, 240),
      operations: sanitizeOperations(parsed.operations)
    };
  } finally {
    clearTimeout(timeout);
  }
}

io.on('connection', (socket) => {
  socket.data.roomCode = null;
  socket.data.lastAiRequest = 0;

  socket.on('room:create', (profile, reply) => {
    leaveRoom(socket);
    const code = makeCode();
    const room = { players: new Map(), mapEdits: [], createdAt: Date.now() };
    rooms.set(code, room);
    joinRoom(socket, code, profile);
    if (typeof reply === 'function') reply({ ok: true, code, players: getPlayers(room), mapEdits: room.mapEdits });
  });

  socket.on('room:join', (payload, reply) => {
    const code = String(payload?.code || '').toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 12);
    const room = rooms.get(code);
    if (!room) {
      if (typeof reply === 'function') reply({ ok: false, error: 'Nie znaleziono pokoju o takim kodzie.' });
      return;
    }
    leaveRoom(socket);
    joinRoom(socket, code, payload?.profile);
    if (typeof reply === 'function') reply({ ok: true, code, players: getPlayers(room), mapEdits: room.mapEdits });
  });

  socket.on('player:move', (state) => {
    const code = socket.data.roomCode;
    const room = code && rooms.get(code);
    if (!room) return;
    const player = room.players.get(socket.id);
    if (!player || !state) return;
    const x = Number(state.x);
    const y = Number(state.y);
    if (!Number.isFinite(x) || !Number.isFinite(y)) return;
    player.x = clamp(x, 24, WORLD_W - 24);
    player.y = clamp(y, 24, WORLD_H - 24);
    player.direction = ['up', 'down', 'left', 'right'].includes(state.direction) ? state.direction : 'down';
    socket.to(code).volatile.emit('player:moved', publicPlayer(player));
  });

  socket.on('ai:edit', async (payload, reply) => {
    const respond = typeof reply === 'function' ? reply : () => {};
    const now = Date.now();
    if (now - socket.data.lastAiRequest < AI_COOLDOWN_MS) {
      respond({ ok: false, error: 'Odczekaj chwilę przed kolejnym poleceniem AI.' });
      return;
    }
    const ip = String(socket.handshake.address || 'unknown').replace(/^::ffff:/, '');
    let usage = aiIpUsage.get(ip);
    if (!usage || now - usage.startedAt >= AI_IP_WINDOW_MS) {
      usage = { startedAt: now, count: 0 };
      aiIpUsage.set(ip, usage);
    }
    if (usage.count >= AI_IP_MAX_REQUESTS) {
      respond({ ok: false, error: 'Limit AI dla tego połączenia został chwilowo wykorzystany. Spróbuj ponownie później.' });
      return;
    }
    usage.count++;
    socket.data.lastAiRequest = now;

    const prompt = String(payload?.prompt || '').trim().replace(/[\u0000-\u001f]/g, ' ').slice(0, 420);
    if (!prompt) {
      respond({ ok: false, error: 'Wpisz, co AI ma zmienić na mapie.' });
      return;
    }

    const code = socket.data.roomCode;
    const room = code && rooms.get(code);
    const player = room?.players.get(socket.id);
    const requestedPosition = payload?.position || {};
    const position = player
      ? { x: Math.round(player.x), y: Math.round(player.y) }
      : {
          x: cleanCoordinate(requestedPosition.x, WORLD_W) || 1300,
          y: cleanCoordinate(requestedPosition.y, WORLD_H) || 1050
        };

    try {
      const result = await askMapBuilder(prompt, position);
      if (!result.operations.length) {
        respond({ ok: true, patch: null, message: result.message || 'Nie trzeba było zmieniać mapy.' });
        return;
      }
      const patch = {
        id: randomUUID(),
        author: player?.nick || 'Gracz',
        message: result.message,
        operations: result.operations,
        createdAt: Date.now()
      };
      if (room) {
        room.mapEdits.push(patch);
        if (room.mapEdits.length > MAX_ROOM_EDITS) room.mapEdits.splice(0, room.mapEdits.length - MAX_ROOM_EDITS);
        io.to(code).emit('world:patch', patch);
      }
      respond({ ok: true, patch, message: result.message });
    } catch (error) {
      const message = error?.name === 'AbortError'
        ? 'AI nie odpowiedziało na czas. Spróbuj ponownie.'
        : String(error?.message || 'Nie udało się połączyć z AI.').slice(0, 300);
      respond({ ok: false, error: message });
    }
  });

  socket.on('disconnect', () => leaveRoom(socket));
});

function joinRoom(socket, code, profile) {
  const room = rooms.get(code);
  if (!room) return;
  const player = {
    id: socket.id,
    nick: cleanName(profile?.nick),
    color: cleanColor(profile?.color),
    x: Number.isFinite(Number(profile?.x)) ? clamp(Number(profile.x), 24, WORLD_W - 24) : 980,
    y: Number.isFinite(Number(profile?.y)) ? clamp(Number(profile.y), 24, WORLD_H - 24) : 760,
    direction: 'down'
  };
  room.players.set(socket.id, player);
  socket.data.roomCode = code;
  socket.join(code);
  socket.emit('room:players', getPlayers(room));
  socket.to(code).emit('player:joined', publicPlayer(player));
}

function getPlayers(room) {
  return Array.from(room.players.values(), publicPlayer);
}

function leaveRoom(socket) {
  const code = socket.data.roomCode;
  if (!code) return;
  const room = rooms.get(code);
  socket.leave(code);
  socket.data.roomCode = null;
  if (!room) return;
  room.players.delete(socket.id);
  socket.to(code).emit('player:left', { id: socket.id });
  if (room.players.size === 0) rooms.delete(code);
}

httpServer.listen(PORT, '0.0.0.0', () => {
  console.log(`Moja Gra RPG — serwer multiplayer działa na porcie ${PORT}`);
  console.log(`Kontrola działania: http://localhost:${PORT}/healthz`);
  console.log(OPENAI_API_KEY
    ? `AI Developer aktywny (${OPENAI_MODEL})`
    : 'AI Developer wyłączony — ustaw OPENAI_API_KEY, aby włączyć edycję mapy przez AI.');
});
